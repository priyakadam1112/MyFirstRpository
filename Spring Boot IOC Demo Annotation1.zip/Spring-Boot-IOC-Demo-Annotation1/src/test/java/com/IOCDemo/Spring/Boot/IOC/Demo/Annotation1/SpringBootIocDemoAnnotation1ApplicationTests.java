package com.IOCDemo.Spring.Boot.IOC.Demo.Annotation1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootIocDemoAnnotation1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
