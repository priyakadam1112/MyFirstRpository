package com.IOCDemo.Spring.Boot.IOC.Demo.Annotation1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootIocDemoAnnotation1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootIocDemoAnnotation1Application.class, args);
	}

}
